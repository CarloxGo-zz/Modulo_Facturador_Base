<?php echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"; ?>
<results>
	<result target="number-a"><?=$count_companys?></result>
	<result target="number-b"><?=$count_segments?></result>
	<result target="number-c"><?=$count_invoices?></result>
</results>