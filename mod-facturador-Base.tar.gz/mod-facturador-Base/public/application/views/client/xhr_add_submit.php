<h1 class="panelTitle">Client Added</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	refreshProjectPanel();
</script>