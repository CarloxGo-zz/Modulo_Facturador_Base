<h1 class="panelTitle">Client Deleted</h1>
<div class="notice">Client has been deleted.</div>
<script type="text/javascript">
	refreshProjectPanel();
</script>