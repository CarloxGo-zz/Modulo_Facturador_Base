<h1 class="panelTitle">Client Updated</h1>
<div class="success">Client has been updated.</div>
<script type="text/javascript">
	refreshProjectPanel();
</script>