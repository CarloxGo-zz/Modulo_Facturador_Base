<form method="post" action="company/logo_submit" enctype="multipart/form-data">
    <input type="file" name="logo_image" value="Select Image" /><br />
    <small>Filetype: JPG (More to come!)<br />
    Filesize: 512 KB max<br />
    Resolution: 200x40-ish (generate sample invoices to test)</small><br />
    <input type="submit" value="Upload Image" />
</form>

<div><br /><br /><small>* Uploading an image will overwrite an existing image.</small></div>