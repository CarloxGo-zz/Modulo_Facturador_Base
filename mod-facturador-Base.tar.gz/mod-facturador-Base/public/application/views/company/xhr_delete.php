<h1 class="panelTitle">DELETE COMPANY PROFILE</h1>
<div class="notice">Are you sure you would like to delete your company profile from NeoInvoice?<br />
	<a onClick="nw('mainPanel', 'company/delete_submit');" class="button">DELETE COMPANY</a> | <a onClick="nw('mainPanel', 'app/dashboard');">Cancel</a>
</div>