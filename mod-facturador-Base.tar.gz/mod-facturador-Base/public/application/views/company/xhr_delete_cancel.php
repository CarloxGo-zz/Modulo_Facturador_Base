<h1 class="panelTitle">Cancel Company Delete</h1>
<div class="success">Your company is no longer going to be deleted.</div>
<script type="text/javascript">
	$('company_deletion').fade('out');
</script>