<h1 class="panelTitle">Company Marked for Deletion</h1>
<div class="success">Your company has been marked for deletion. It will be deleted in one week.<br />
	<a onClick="nw('mainPanel', 'company/delete_cancel');">Cancel Company Deletion</a>
</div>