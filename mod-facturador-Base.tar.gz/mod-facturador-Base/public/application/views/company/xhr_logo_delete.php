<h1 class="panelTitle">Delete Logo Image</h1>
<div class="notice">Are you sure you would like to delete your invoice logo image? Your invoices will default to using the name of the company instead.<br />
	<a onClick="nw('mainPanel', 'company/logo_delete_submit');" class="button">Delete Logo Image</a> | <a onClick="nw('mainPanel', 'company/preferences');">Cancel</a>
</div>