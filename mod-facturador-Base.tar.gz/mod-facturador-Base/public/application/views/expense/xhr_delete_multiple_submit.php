<h1 class="panelTitle">Multiple Expenses Deleted</h1>
<div class="success"><?=$message?></div>