<h1 class="panelTitle">Expense Deleted</h1>
<div class="success"><?=$message?></div>