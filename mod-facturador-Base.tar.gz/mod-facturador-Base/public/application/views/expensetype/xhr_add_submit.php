<h1 class="panelTitle">Expense Type Added</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	nw('mainPanel', 'expensetype/list_items');
</script>