<h1 class="panelTitle">Expense Type Updated</h1>
<div class="success">Expense Type has been updated.</div>
<script type="text/javascript">
	nw('mainPanel', 'expensetype/list_items');
</script>