<h1 class="panelTitle">Invoice Updated</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	refreshInvoicePanel();
</script>