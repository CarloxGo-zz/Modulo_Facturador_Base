<h1 class="panelTitle">Invoice Sent</h1>
<div class="success"><?=$message?></div>