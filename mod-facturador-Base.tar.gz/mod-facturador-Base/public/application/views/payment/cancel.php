<div class="panelContentPad">
	<h2>Payment Canceled!</h2>

	<p>You have chosen to cancel the process of upgrading your company account. If
		you have any questions about the process or would like to report any issues,
		please use the <a href="contact">contact</a> form and we will be glad to
		answer.</p>

	<p>If you do not still have the application open in another tab or window, you
		can click <a href="app">here</a> to return.</p>
</div>