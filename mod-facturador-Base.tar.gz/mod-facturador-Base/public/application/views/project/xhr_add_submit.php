<h1 class="panelTitle">Project Created</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	refreshProjectPanel();
</script>