<h1 class="panelTitle">Project Updated</h1>
<div class="success">Project has been updated.</div>
<script type="text/javascript">
	refreshProjectPanel();
</script>