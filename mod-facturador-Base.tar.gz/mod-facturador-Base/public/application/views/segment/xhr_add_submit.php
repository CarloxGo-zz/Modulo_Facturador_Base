<h1 class="panelTitle">Time Recorded</h1>
<div class="success"><?=$message?></div>