<h1 class="panelTitle">Multiple Recorded Times Deleted</h1>
<div class="success"><?=$message?></div>