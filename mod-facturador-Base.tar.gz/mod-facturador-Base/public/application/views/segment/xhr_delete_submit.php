<h1 class="panelTitle">Recorded Time Deleted</h1>
<div class="success"><?=$message?></div>