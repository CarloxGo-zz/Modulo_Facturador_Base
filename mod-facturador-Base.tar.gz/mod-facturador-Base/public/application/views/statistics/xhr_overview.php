<h1 class="panelTitle">Company Statistics</h1>
<h2>Work Type Breakdown: All Time</h2>
<p>This graph shows how much time has been put into each work-type for all time.</p>
<div style="text-align: center;"><img src="<?=$worktypes?>" alt="Worktype Breakdown" /></div>
<br />

<h2>Work Amount Breakdown: All Time</h2>
<p>This graph shows how much time each teammate has recorded for all time.</p>
<div style="text-align: center;"><img src="<?=$usertimes?>" alt="Work Amount Breakdown" /></div>
<br />
