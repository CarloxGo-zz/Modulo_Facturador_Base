<h1 class="panelTitle">Ticket Deleted</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	refreshTicketPanel();
</script>