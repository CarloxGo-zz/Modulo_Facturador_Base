<h1 class="panelTitle">Ticket Updated</h1>
<div class="success">Ticket has been updated.</div>
<script type="text/javascript">
	refreshTicketPanel();
</script>