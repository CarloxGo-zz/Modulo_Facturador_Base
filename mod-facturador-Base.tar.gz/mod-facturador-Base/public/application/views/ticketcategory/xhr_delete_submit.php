<h1 class="panelTitle">Ticket Category Deleted</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	nw('mainPanel', 'ticketcategory/list_items');
</script>