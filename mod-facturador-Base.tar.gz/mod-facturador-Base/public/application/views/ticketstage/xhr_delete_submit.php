<h1 class="panelTitle">Ticket Stage Deleted</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	nw('mainPanel', 'ticketstage/list_items');
</script>