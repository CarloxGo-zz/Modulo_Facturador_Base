<h1 class="panelTitle">Ticket Stage Updated</h1>
<div class="success">Ticket Stage has been updated.</div>
<script type="text/javascript">
	nw('mainPanel', 'ticketstage/list_items');
</script>