<h1 class="panelTitle">Teammate Deleted</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	refreshTeammatePanel();
</script>