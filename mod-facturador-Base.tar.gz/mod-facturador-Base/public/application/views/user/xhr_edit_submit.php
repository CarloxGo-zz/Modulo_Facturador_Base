<h1 class="panelTitle">Teammate Updated</h1>
<div class="success">Teammate has been updated.</div>
<script type="text/javascript">
	refreshTeammatePanel();
</script>