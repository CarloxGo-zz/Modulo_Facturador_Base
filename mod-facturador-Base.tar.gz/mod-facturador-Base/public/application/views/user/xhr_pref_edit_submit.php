<h1 class="panelTitle">Preferences Updated</h1>
<div class="success">Preferences have been saved. For some settings to take effect the application interface will need to be <a onClick="window.location.reload(true);">reloaded</a>.</div>
<script type="text/javascript">
	refreshTeammatePanel();
</script>