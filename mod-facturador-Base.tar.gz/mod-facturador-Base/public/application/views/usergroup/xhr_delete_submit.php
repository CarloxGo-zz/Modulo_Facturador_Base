<h1 class="panelTitle">User Group Deleted</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	nw('mainPanel', 'usergroup/list_items');
</script>