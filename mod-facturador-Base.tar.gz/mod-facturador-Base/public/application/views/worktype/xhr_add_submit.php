<h1 class="panelTitle">Work Type Added</h1>
<div class="success"><?=$message?></div>
<script type="text/javascript">
	nw('mainPanel', 'worktype/list_items');
</script>