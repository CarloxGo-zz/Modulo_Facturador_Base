<h1 class="panelTitle">Work Type Updated</h1>
<div class="success">Work Type has been updated.</div>
<script type="text/javascript">
	nw('mainPanel', 'worktype/list_items');
</script>