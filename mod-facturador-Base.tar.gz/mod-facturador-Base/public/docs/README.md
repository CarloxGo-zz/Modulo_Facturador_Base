Wordpress
=

In this directory you'll want to install wordpress. Also, install the database
along-side the normal database, prefixing each table with wp_. This will allow
the wordpress_model.php file to read the recent entries in the updates category.

This is of course entirely optional.
