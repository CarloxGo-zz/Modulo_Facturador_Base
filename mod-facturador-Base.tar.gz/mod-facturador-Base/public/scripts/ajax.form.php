<div id="postContent">
	<?php
		print "<pre>".print_r($_POST, true)."</pre>";
	?>
</div>