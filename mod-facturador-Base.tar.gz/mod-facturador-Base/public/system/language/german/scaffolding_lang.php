<?php

$lang['scaff_view_records']		= 'Datens&auml;tze anzeigen';
$lang['scaff_create_record']	= 'Neuen Datensatz erzeugen';
$lang['scaff_add']				= 'Daten hinzuf&uuml;gen';
$lang['scaff_view']				= 'Daten anzeigen';
$lang['scaff_edit']				= 'Bearbeiten';
$lang['scaff_delete']			= 'L&ouml;schen';
$lang['scaff_view_all']			= 'Alle anzeigen';
$lang['scaff_yes']				= 'Ja';
$lang['scaff_no']				= 'Nein';
$lang['scaff_no_data']			= 'In dieser Tabelle sind keine Daten gespeichert.';
$lang['scaff_del_confirm']		= 'Bitte best&auml;tigen Sie, dass die folgende Zeile tats&auml;chlich gel&ouml;scht werden soll:';


/* End of file scaffolding_lang.php */
/* Location: ./system/language/german/scaffolding_lang.php */