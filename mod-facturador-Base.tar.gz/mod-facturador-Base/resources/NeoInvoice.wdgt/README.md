OS X Dashboard Widget
=

This is the code for the dashboard widget. I didn't realize Xcode made it easy
to build widgets, so I built it from scratch. For more information on the methods
used, check out this URL:

http://thomashunter.name/blog/building-custom-os-x-dashboard-widgets/
