Resources
=

This is where I stick files which aren't really part of the app.
Technically they shouldn't be a part of the git repo, but oh well.
